/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tleger <tleger@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/09/22 20:22:14 by tleger            #+#    #+#             */
/*   Updated: 2015/09/22 20:25:15 by tleger           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void	ft_swap(int *a, int *b);

int		main(int argc, char *argv[])
{
	int a;
	int b;
	int *ptra;
	int *ptrb;
	if (argc == 3)
	{
		a = atoi(argv[1]);
		b = atoi(argv[2]);
		ptra = &a;
		ptrb = &b;
		ft_swap(ptra, ptrb);
		printf("%d, %d\n", a, b);
	}
	return (0);
}
