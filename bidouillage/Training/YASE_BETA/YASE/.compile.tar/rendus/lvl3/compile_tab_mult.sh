gcc -Wall -Wextra -Werror -o ./rendus/lvl3/tab_mult/tab_mult.out ./rendus/lvl3/tab_mult/tab_mult.c
