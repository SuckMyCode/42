gcc -Wall -Wextra -Werror -o ./rendus/lvl3/paramsum/paramsum.out ./rendus/lvl3/paramsum/paramsum.c
