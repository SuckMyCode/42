gcc -Wall -Wextra -Werror -o ./rendus/lvl3/ft_swap/ft_swap.out ./rendus/lvl3/ft_swap/ft_swap.c ./rendus/lvl3/ft_swap/main.c
rm -f ./rendus/lvl3/ft_swap/main.c
