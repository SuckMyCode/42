gcc -Wall -Wextra -Werror -o ./rendus/lvl3/hidenp/hidenp.out ./rendus/lvl3/hidenp/hidenp.c
