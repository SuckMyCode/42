gcc -Wall -Wextra -Werror -o ./rendus/lvl3/expand_str/expand_str.out ./rendus/lvl3/expand_str/expand_str.c
