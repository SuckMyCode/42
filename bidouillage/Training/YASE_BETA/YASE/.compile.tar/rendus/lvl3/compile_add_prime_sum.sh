gcc -Wall -Wextra -Werror -o ./rendus/lvl3/add_prime_sum/add_prime_sum.out ./rendus/lvl3/add_prime_sum/add_prime_sum.c
