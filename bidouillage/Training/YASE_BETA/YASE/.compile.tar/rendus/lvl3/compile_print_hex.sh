gcc -Wall -Wextra -Werror -o ./rendus/lvl3/print_hex/print_hex.out ./rendus/lvl3/print_hex/print_hex.c
