gcc -Wall -Wextra -Werror -o ./rendus/lvl3/pgcd/pgcd.out ./rendus/lvl3/pgcd/pgcd.c
