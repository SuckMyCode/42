gcc -Wall -Wextra -Werror -o ./rendus/lvl3/ft_range/ft_range.out ./rendus/lvl3/ft_range/ft_range.c ./rendus/lvl3/ft_range/main.c
