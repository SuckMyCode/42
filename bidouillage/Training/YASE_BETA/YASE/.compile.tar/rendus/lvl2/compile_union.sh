gcc -Wall -Wextra -Werror -o ./rendus/lvl2/union/union.out ./rendus/lvl2/union/union.c
