gcc -Wall -Wextra -Werror -o ./rendus/lvl2/wdmatch/wdmatch.out ./rendus/lvl2/wdmatch/wdmatch.c
