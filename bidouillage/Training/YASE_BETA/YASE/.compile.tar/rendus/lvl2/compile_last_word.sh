gcc -Wall -Wextra -Werror -o ./rendus/lvl2/last_word/last_word.out ./rendus/lvl2/last_word/last_word.c
