gcc -Wall -Wextra -Werror -o ./rendus/lvl2/do_op/do_op.out ./rendus/lvl2/do_op/do_op.c
