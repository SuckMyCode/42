gcc -Wall -Wextra -Werror -o ./rendus/lvl2/alpha_mirror/alpha_mirror.out ./rendus/lvl2/alpha_mirror/alpha_mirror.c
