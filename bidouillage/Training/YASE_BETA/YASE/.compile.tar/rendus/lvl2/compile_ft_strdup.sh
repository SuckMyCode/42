gcc -Wall -Wextra -Werror -o ./rendus/lvl2/ft_strdup/ft_strdup.out ./rendus/lvl2/ft_strdup/ft_strdup.c ./rendus/lvl2/ft_strdup/main.c
rm -f ./rendus/lvl2/ft_strdup/main.c
