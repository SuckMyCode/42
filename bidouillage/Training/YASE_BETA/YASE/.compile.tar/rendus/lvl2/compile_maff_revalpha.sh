gcc -Wall -Wextra -Werror -o ./rendus/lvl2/maff_revalpha/maff_revalpha.out ./rendus/lvl2/maff_revalpha/maff_revalpha.c
