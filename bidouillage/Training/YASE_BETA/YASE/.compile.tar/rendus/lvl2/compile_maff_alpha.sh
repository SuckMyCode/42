gcc -Wall -Wextra -Werror -o ./rendus/lvl2/maff_alpha/maff_alpha.out ./rendus/lvl2/maff_alpha/maff_alpha.c
