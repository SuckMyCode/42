gcc -Wall -Wextra -Werror -o ./rendus/lvl2/ft_strrev/ft_strrev.out ./rendus/lvl2/ft_strrev/ft_strrev.c ./rendus/lvl2/ft_strrev/main.cat
rm -f ./rendus/lvl2/ft_strrev/main.cat
