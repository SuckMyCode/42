gcc -Wall -Wextra -Werror -o ./rendus/lvl0/only_a/only_a.out ./rendus/lvl0/only_a/only_a.c
