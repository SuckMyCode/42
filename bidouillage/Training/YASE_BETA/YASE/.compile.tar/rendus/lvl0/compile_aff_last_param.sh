gcc -Wall -Wextra -Werror -o ./rendus/lvl0/aff_last_param/aff_last_param.out ./rendus/lvl0/aff_last_param/aff_last_param.c
