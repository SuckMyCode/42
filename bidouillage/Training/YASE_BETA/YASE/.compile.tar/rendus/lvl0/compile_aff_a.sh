gcc -Wall -Wextra -Werror -o ./rendus/lvl0/aff_a/aff_a.out ./rendus/lvl0/aff_a/aff_a.c
