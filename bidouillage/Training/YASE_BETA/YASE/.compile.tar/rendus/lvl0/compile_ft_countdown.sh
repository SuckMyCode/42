gcc -Wall -Wextra -Werror -o ./rendus/lvl0/ft_countdown/ft_countdown.out ./rendus/lvl0/ft_countdown/ft_countdown.c
