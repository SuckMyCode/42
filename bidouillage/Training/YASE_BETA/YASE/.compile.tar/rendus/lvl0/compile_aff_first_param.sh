gcc -Wall -Wextra -Werror -o ./rendus/lvl0/aff_first_param/aff_first_param.out ./rendus/lvl0/aff_first_param/aff_first_param.c
