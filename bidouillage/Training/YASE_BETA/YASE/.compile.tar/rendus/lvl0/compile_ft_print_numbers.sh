gcc -Wall -Wextra -Werror -o ./rendus/lvl0/ft_print_numbers/ft_print_numbers.out ./rendus/lvl0/ft_print_numbers/ft_print_numbers.c ./rendus/lvl0/ft_print_numbers/main.c
rm -f ./rendus/lvl0/ft_print_numbers/main.c
