gcc -Wall -Wextra -Werror -o ./rendus/lvl0/only_z/only_z.out ./rendus/lvl0/only_z/only_z.c
