gcc -Wall -Wextra -Werror -o ./rendus/lvl1/ft_putstr/ft_putstr.out ./rendus/lvl1/ft_putstr/putstr.c ./rendus/lvl1/ft_putstr/main.c
rm -f ./rendus/lvl1/ft_putstr/main.c
