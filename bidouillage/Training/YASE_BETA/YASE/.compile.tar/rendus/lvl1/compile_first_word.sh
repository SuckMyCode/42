gcc -Wall -Wextra -Werror -o ./rendus/lvl1/first_word/first_word.out ./rendus/lvl1/first_word/first_word.c
