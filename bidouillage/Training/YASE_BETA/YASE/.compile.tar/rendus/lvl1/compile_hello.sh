gcc -Wall -Wextra -Werror -o ./rendus/lvl1/hello/hello.out ./rendus/lvl1/hello/hello.c
