gcc -Wall -Wextra -Werror -o ./rendus/lvl1/ft_strlen/ft_strlen.out ./rendus/lvl1/ft_strlen/ft_strlen.c ./rendus/lvl1/ft_strlen/main.c
