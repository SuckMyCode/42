gcc -Wall -Wextra -Werror -o ./rendus/lvl1/search_and_replace/search_and_replace.out ./rendus/lvl1/search_and_replace/search_and_replace.c
