gcc -Wall -Wextra -Werror -o ./rendus/lvl1/ulstr/ulstr.out ./rendus/lvl1/ulstr/ulstr.c
