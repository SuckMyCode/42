gcc -Wall -Wextra -Werror -o ./rendus/lvl1/repeat_alpha/repeat_alpha.out ./rendus/lvl1/repeat_alpha/repeat_alpha.c
