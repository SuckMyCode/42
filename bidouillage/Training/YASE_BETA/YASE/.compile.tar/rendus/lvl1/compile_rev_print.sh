gcc -Wall -Wextra -Werror -o ./rendus/lvl1/rev_print/rev_print.out ./rendus/lvl1/rev_print/rev_print.c
