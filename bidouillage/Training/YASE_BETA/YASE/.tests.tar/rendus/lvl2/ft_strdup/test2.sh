./rendus/lvl2/ft_strdup/ft_strdup.out > user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref > test_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.out "" >> user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref "" >> test_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.out "DNR" >> user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref "DNR" >> test_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.out "mhM" >> user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref "mhM" >> test_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.out "ADeCxqUEX8S0jorM" >> user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref "ADeCxqUEX8S0jorM" >> test_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.out "QlRFhe" >> user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref "QlRFhe" >> test_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.out "CY9ysq7 NIcAHkq5PGLiOt0 VNs Ff16 UyAh6 F9IPekMi IPpkr tGL5 SaWNT 9InB3xfX4ZJDRs 1EAQqHp6U8 HeTlvFf1g3 kNq2hueTDbtclZ5Qm s7u 9hmCTHxPNnlUI CxV" >> user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref "CY9ysq7 NIcAHkq5PGLiOt0 VNs Ff16 UyAh6 F9IPekMi IPpkr tGL5 SaWNT 9InB3xfX4ZJDRs 1EAQqHp6U8 HeTlvFf1g3 kNq2hueTDbtclZ5Qm s7u 9hmCTHxPNnlUI CxV" >> test_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.out "SzUabDq2CP yObIWncJPswHN6Y x518yvZeoaz0YV 0U1iW8 vVt94sPDbM WQ2DYBX6PKobx7t HzmrTM IZ37iM DAPgyrSq6VxtXlnp vf6MRdTgVN av2PxYyrMUGH qXzlI 1TAkYv4M 3xyICzTWFZrq zFqS C34LAcPkOB V8KHo9dA" >> user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref "SzUabDq2CP yObIWncJPswHN6Y x518yvZeoaz0YV 0U1iW8 vVt94sPDbM WQ2DYBX6PKobx7t HzmrTM IZ37iM DAPgyrSq6VxtXlnp vf6MRdTgVN av2PxYyrMUGH qXzlI 1TAkYv4M 3xyICzTWFZrq zFqS C34LAcPkOB V8KHo9dA" >> test_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.out "2FOn30JyRgBAwfe7 1kbFNGOVez lWLsxIY emivwd phGj5gNxIcUDoW pGwi3uCPhAvo8l42c fGeC8MxkUJB0cR vGR2Pg nWKGE4 eyB 94xQUPfGHDthywkMe UAYgmjesiCpGbF mNCuBMUW" >> user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref "2FOn30JyRgBAwfe7 1kbFNGOVez lWLsxIY emivwd phGj5gNxIcUDoW pGwi3uCPhAvo8l42c fGeC8MxkUJB0cR vGR2Pg nWKGE4 eyB 94xQUPfGHDthywkMe UAYgmjesiCpGbF mNCuBMUW" >> test_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.out "3soOKVmj f7vdS8 K4ftvPjkE0i CHR FhflZ91xO87qD CWRV pRc7fgo503aNOvB u6qg4rD2NKX pFhskrd6vogR0 UsK Bdqp u643W r8baio ly8xU" >> user_output.txt
./rendus/lvl2/ft_strdup/ft_strdup.ref "3soOKVmj f7vdS8 K4ftvPjkE0i CHR FhflZ91xO87qD CWRV pRc7fgo503aNOvB u6qg4rD2NKX pFhskrd6vogR0 UsK Bdqp u643W r8baio ly8xU" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl2/ft_strdup.trace.txt
rm -f *output.txt
rm -f test.sh
