./rendus/lvl2/union/union.out > user_output.txt
./rendus/lvl2/union/union.ref > test_output.txt
./rendus/lvl2/union/union.out "bqwuiobqiwrvi-1,-1.-1-38901gbi" "u3bkjnqoq8dbiu1p1po,-8491" >> user_output.txt
./rendus/lvl2/union/union.ref "bqwuiobqiwrvi-1,-1.-1-38901gbi" "u3bkjnqoq8dbiu1p1po,-8491" >> test_output.txt
./rendus/lvl2/union/union.out "" "3u3bkjnqosbhs9q8dbiu1p1po,-8491" >> user_output.txt
./rendus/lvl2/union/union.ref "" "3u3bkjnqosbhs9q8dbiu1p1po,-8491" >> test_output.txt
./rendus/lvl2/union/union.out "" "" >> user_output.txt
./rendus/lvl2/union/union.ref "" "" >> test_output.txt
./rendus/lvl2/union/union.out "bqkwjbwqiuqw" "" >> user_output.txt
./rendus/lvl2/union/union.ref "bqkwjbwqiuqw" "" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl2/union.trace.txt
rm -f *output.txt
rm -f test.sh
