./rendus/lvl2/maff_alpha/maff_alpha.out > user_output.txt
./rendus/lvl2/maff_alpha/maff_alpha.ref > test_output.txt
./rendus/lvl2/maff_alpha/maff_alpha.out "17" "23" "42" >> user_output.txt
./rendus/lvl2/maff_alpha/maff_alpha.ref "17" "23" "42" >> test_output.txt
./rendus/lvl2/maff_alpha/maff_alpha.out "4Hn82arQVcsA6Ke" >> user_output.txt
./rendus/lvl2/maff_alpha/maff_alpha.ref "4Hn82arQVcsA6Ke" >> test_output.txt
./rendus/lvl2/maff_alpha/maff_alpha.out "AuHa" >> user_output.txt
./rendus/lvl2/maff_alpha/maff_alpha.ref "AuHa" >> test_output.txt
./rendus/lvl2/maff_alpha/maff_alpha.out "PdVmwT" >> user_output.txt
./rendus/lvl2/maff_alpha/maff_alpha.ref "8shKMYf2H90EOVpGt" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl2/maff_alpha.trace.txt
rm -f *output.txt
rm -f test.sh
