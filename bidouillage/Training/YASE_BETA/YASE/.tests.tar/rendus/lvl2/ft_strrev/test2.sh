./rendus/lvl2/ft_strrev/ft_strrev.out > user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref > test_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.out "" >> user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref "" >> test_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.out "Si7wT2EMmXqFfbuk" >> user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref "Si7wT2EMmXqFfbuk" >> test_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.out "ZiEYMjry" >> user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref "ZiEYMjry" >> test_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.out "fI8FmJw" >> user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref "fI8FmJw" >> test_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.out "38Y" >> user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref "38Y" >> test_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.out "MLcqD1vRn7S4 VhB8MRKUSfEm4H19 fjm31ip UMrPyCbapJBY PhNKOZxUA9Wd7 18a s2oaUbnT BqIca PQecRH8FyTZmLVx" >> user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref "MLcqD1vRn7S4 VhB8MRKUSfEm4H19 fjm31ip UMrPyCbapJBY PhNKOZxUA9Wd7 18a s2oaUbnT BqIca PQecRH8FyTZmLVx" >> test_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.out "T9V8XMtwp7fRd DLteGRQk0MBU3 GwQHrlfOiymo ziDpQ7mJ4Rh1aC5N 78IxMwoOcaTV HPS3Ji eN65vRuAYQF tNM glAGmDnzf7T35KL6 KlXN5tFuapom 7zg0GhxDmLaYuk5d DIdfc5kGt EnRLVGOJy2SAZax7" >> user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref "T9V8XMtwp7fRd DLteGRQk0MBU3 GwQHrlfOiymo ziDpQ7mJ4Rh1aC5N 78IxMwoOcaTV HPS3Ji eN65vRuAYQF tNM glAGmDnzf7T35KL6 KlXN5tFuapom 7zg0GhxDmLaYuk5d DIdfc5kGt EnRLVGOJy2SAZax7" >> test_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.out "uCgd7jKt 5EL2Vg TbIBN6UKe2 uOR2U ZGHm4 jOelwUyTtuQn" >> user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref "uCgd7jKt 5EL2Vg TbIBN6UKe2 uOR2U ZGHm4 jOelwUyTtuQn" >> test_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.out "ieUvTajX5rdm EtR2bUJ1xnsWpT Zd6LA UfaWR" >> user_output.txt
./rendus/lvl2/ft_strrev/ft_strrev.ref "ieUvTajX5rdm EtR2bUJ1xnsWpT Zd6LA UfaWR" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl2/ft_strrev.trace.txt
rm -f *output.txt
rm -f test.sh
