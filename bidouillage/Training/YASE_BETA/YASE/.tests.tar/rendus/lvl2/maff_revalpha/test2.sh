./rendus/lvl2/maff_revalpha/maff_revalpha.out > user_output.txt
./rendus/lvl2/maff_revalpha/maff_revalpha.ref > test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl2/maff_revalpha.trace.txt
rm -f *output.txt
rm -f test.sh
