./rendus/lvl2/alpha_mirror/alpha_mirror.out >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "npl5VToF0jhS" "dleqQs3" "QP6Ue0jx4" "KkdcEBT2s" "pbUuY6M8D" "GIOSWtLy1vn3RXcE" "Mgsyv2Vw" "WO6YtdnNcgMf" "QyAU2YqCmatbj1ruk" "6boLHfM7" "ximha" "qgz8ec" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "npl5VToF0jhS" "dleqQs3" "QP6Ue0jx4" "KkdcEBT2s" "pbUuY6M8D" "GIOSWtLy1vn3RXcE" "Mgsyv2Vw" "WO6YtdnNcgMf" "QyAU2YqCmatbj1ruk" "6boLHfM7" "ximha" "qgz8ec" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "k1bVAWZS" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "k1bVAWZS" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "KgdaRnxq" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "KgdaRnxq" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "coHO" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "coHO" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "32VFyLZRvN" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "32VFyLZRvN" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "zdLPBivfkT" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "zdLPBivfkT" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "xe9gD2h1cinl" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "xe9gD2h1cinl" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "0Yfw19g3n4b" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "0Yfw19g3n4b" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "6UhZ9z1vENCog" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "6UhZ9z1vENCog" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "0cnXLm1BhRZFsG AZYqdCzbfrBHUG50M vRnrLze450HTpY 5hO4n I0mXeMJwL5vPh ySJGX7H jeiCal3Lkzp2rV8gc lKvCzg4OPV" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "0cnXLm1BhRZFsG AZYqdCzbfrBHUG50M vRnrLze450HTpY 5hO4n I0mXeMJwL5vPh ySJGX7H jeiCal3Lkzp2rV8gc lKvCzg4OPV" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "w6ev8 IOZYThMLaiP ZwdzR7rLVTCm 9PWh TAP6g9zKUY7nopwJ GBuSxFk6yMVl1gZN5 cahp 6N5o1wr 0NjO I2k ST9aQiKd aiTPYLH nDQqVNyRrKAGhxZ7l" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "w6ev8 IOZYThMLaiP ZwdzR7rLVTCm 9PWh TAP6g9zKUY7nopwJ GBuSxFk6yMVl1gZN5 cahp 6N5o1wr 0NjO I2k ST9aQiKd aiTPYLH nDQqVNyRrKAGhxZ7l" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "2zpW DYEKVkQSf84Mq3mnX iHqx Xkvfo1W4qgZejDTEi rx5b" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "2zpW DYEKVkQSf84Mq3mnX iHqx Xkvfo1W4qgZejDTEi rx5b" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "9pV AakylCF5YpBH9wPx okelvFtWqIys6b n3m 6sY0w4myQKji bYlO v9qzJmtZVks84iPL" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "9pV AakylCF5YpBH9wPx okelvFtWqIys6b n3m 6sY0w4myQKji bYlO v9qzJmtZVks84iPL" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "TO8erHnClyf MIloE0NSuknwFLv dJna1irRH PEnrfLJB6Tw WhspbaywnQ9CIvBM5 gDUsBdHv1Alf6qrma xJm76NqYsyj gJ2r1RoGUFc 5TrX7D1eilGK yxW5 4iltHKnovLNQGR7Y" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "TO8erHnClyf MIloE0NSuknwFLv dJna1irRH PEnrfLJB6Tw WhspbaywnQ9CIvBM5 gDUsBdHv1Alf6qrma xJm76NqYsyj gJ2r1RoGUFc 5TrX7D1eilGK yxW5 4iltHKnovLNQGR7Y" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "F423p zHXiStkaQ qyrjxGCzZDF0c lTq 0DTm 8vaeGMHyhlpqB297 QUsW" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "F423p zHXiStkaQ qyrjxGCzZDF0c lTq 0DTm 8vaeGMHyhlpqB297 QUsW" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "cidEUTqJKNw Ff348ls2nHvk CErLQ0M oCZ69gWIis ZXbgKV 5ZWAfiHzRyruI21ke eSbDT6h ItjS zdHcsQuLRb9XSW14U H8oQRDiY2nKSUsf1F wyixELKtmPSj04YT 9Gvnp Pwvx1UczgkNn4 8Jk A2GDU4patl OkyrY2q" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "cidEUTqJKNw Ff348ls2nHvk CErLQ0M oCZ69gWIis ZXbgKV 5ZWAfiHzRyruI21ke eSbDT6h ItjS zdHcsQuLRb9XSW14U H8oQRDiY2nKSUsf1F wyixELKtmPSj04YT 9Gvnp Pwvx1UczgkNn4 8Jk A2GDU4patl OkyrY2q" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "iueapgjVqwkz Sgjuf Aq5E vk2 vDcnI5Py e6aojyMlsLW EJyvD rExZe Gr8MZknDpS 2a6 fUBnhgFm" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "iueapgjVqwkz Sgjuf Aq5E vk2 vDcnI5Py e6aojyMlsLW EJyvD rExZe Gr8MZknDpS 2a6 fUBnhgFm" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "GjQ Jbd9mB qj6DGcQ YuTmsH1lfb6dvgZ nCriP1h xfuF6IrtiWP nwKjW9QNi4 FUGfZ5RCaj7VLmucb RatGCl2mI07r m7qMnfPUSjJI2d3L V1yekAY9M3tU 25TohsPSw Usz987J0QWYD hPQzB41aVl 4FjmNwHWUOCqad lauR56qO9k0Em7 f8owdVOW9 qXbDc0">> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "GjQ Jbd9mB qj6DGcQ YuTmsH1lfb6dvgZ nCriP1h xfuF6IrtiWP nwKjW9QNi4 FUGfZ5RCaj7VLmucb RatGCl2mI07r m7qMnfPUSjJI2d3L V1yekAY9M3tU 25TohsPSw Usz987J0QWYD hPQzB41aVl 4FjmNwHWUOCqad lauR56qO9k0Em7 f8owdVOW9 qXbDc0" >> user_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.out "FV2eIuk4hCO78UH10 bxS jLZySIed7lN PzMBljNb pZhne SOY gj3uQTVfKAMiawZE ysvST8dguLm6 PdOogS Fw0jRm xb35j0MBur4 GA3VPT1 psvHCEZ tBOU30pfCI1mnYhl oy4X6vMwVsfd" >> test_output.txt
./rendus/lvl2/alpha_mirror/alpha_mirror.ref "FV2eIuk4hCO78UH10 bxS jLZySIed7lN PzMBljNb pZhne SOY gj3uQTVfKAMiawZE ysvST8dguLm6 PdOogS Fw0jRm xb35j0MBur4 GA3VPT1 psvHCEZ tBOU30pfCI1mnYhl oy4X6vMwVsfd" >> user_output.txt

diff -U 3 user_output.txt test_output.txt >> ./traces/lvl2/alpha_mirror.trace.txt
rm -f *output.txt
rm -f test.sh
