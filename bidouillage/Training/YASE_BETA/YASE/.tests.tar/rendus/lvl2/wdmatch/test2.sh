./rendus/lvl2/wdmatch/wdmatch.out > user_output.txt
./rendus/lvl2/wdmatch/wdmatch.ref > test_output.txt
./rendus/lvl2/wdmatch/wdmatch.out "faya" "fgvvfdxcacpolhyghbreda" >> user_output.txt
./rendus/lvl2/wdmatch/wdmatch.ref "faya" "fgvvfdxcacpolhyghbreda" >> test_output.txt
./rendus/lvl2/wdmatch/wdmatch.out "faya" "fgvvfdxcacpolhyghbred" >> user_output.txt
./rendus/lvl2/wdmatch/wdmatch.ref "faya" "fgvvfdxcacpolhyghbred" >> test_output.txt
./rendus/lvl2/wdmatch/wdmatch.out "quarante deux" "qfqfsudf arzgsayns tsregfdgs sjytdekuoixq " >> user_output.txt
./rendus/lvl2/wdmatch/wdmatch.ref "quarante deux" "qfqfsudf arzgsayns tsregfdgs sjytdekuoixq " >> test_output.txt
./rendus/lvl2/wdmatch/wdmatch.out "rrerrrfiiljdfxjyuifrrvcoojh" >> user_output.txt
./rendus/lvl2/wdmatch/wdmatch.ref "rrerrrfiiljdfxjyuifrrvcoojh" >> test_output.txt
./rendus/lvl2/wdmatch/wdmatch.out "... un dernier pour la route" "... UN DERNIER POUR LA ROUTE" >> user_output.txt
./rendus/lvl2/wdmatch/wdmatch.ref "... un dernier pour la route" "... UN DERNIER POUR LA ROUTE" >> test_output.txt
./rendus/lvl2/wdmatch/wdmatch.out "oui" "qowueir" >> user_output.txt
./rendus/lvl2/wdmatch/wdmatch.ref "oui" "qowueir" >> test_output.txt
./rendus/lvl2/wdmatch/wdmatch.out "" >> user_output.txt
./rendus/lvl2/wdmatch/wdmatch.ref "" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl2/wdmatch.trace.txt
rm -f *output.txt
rm -f test.sh
