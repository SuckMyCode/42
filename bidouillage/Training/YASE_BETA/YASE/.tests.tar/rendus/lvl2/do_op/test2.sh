./rendus/lvl2/do_op/do_op.out > user_output.txt
./rendus/lvl2/do_op/do_op.ref > test_output.txt
./rendus/lvl2/do_op/do_op.out "21" "*" "2" >> user_output.txt
./rendus/lvl2/do_op/do_op.ref "21" "*" "2" >> test_output.txt
./rendus/lvl2/do_op/do_op.out "1" "+" "-1" >> user_output.txt
./rendus/lvl2/do_op/do_op.ref "1" "+" "-1" >> test_output.txt
./rendus/lvl2/do_op/do_op.out "1" "+" "-43" >> user_output.txt
./rendus/lvl2/do_op/do_op.ref "1" "+" "-43" >> test_output.txt
./rendus/lvl2/do_op/do_op.out "7" "%" "2" >> user_output.txt
./rendus/lvl2/do_op/do_op.ref "7" "%" "2" >> test_output.txt
./rendus/lvl2/do_op/do_op.out "7" "/" "3" >> user_output.txt
./rendus/lvl2/do_op/do_op.ref "7" "/" "3" >> test_output.txt
./rendus/lvl2/do_op/do_op.out "324" "-" "124" >> user_output.txt
./rendus/lvl2/do_op/do_op.ref "324" "-" "124" >> test_output.txt
./rendus/lvl2/do_op/do_op.out "" >> user_output.txt
./rendus/lvl2/do_op/do_op.ref "" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl2/do_op.trace.txt
rm -f *output.txt
rm -f test.sh
