./rendus/lvl3/expand_str/expand_str.out > user_output.txt
./rendus/lvl3/expand_str/expand_str.ref > test_output.txt
./rendus/lvl3/expand_str/expand_str.out " fa f ds f ff" " few" >> user_output.txt
./rendus/lvl3/expand_str/expand_str.ref " fa f ds f ff" " few" >> test_output.txt
./rendus/lvl3/expand_str/expand_str.out " this is   f-u-b-a-r      " >> user_output.txt
./rendus/lvl3/expand_str/expand_str.ref " this is   f-u-b-a-r      " >> test_output.txt
./rendus/lvl3/expand_str/expand_str.out "mon poney s'apelle poussiere d'etoile" >> user_output.txt
./rendus/lvl3/expand_str/expand_str.ref "mon poney s'apelle poussiere d'etoile" >> test_output.txt
./rendus/lvl3/expand_str/expand_str.out "" >> user_output.txt
./rendus/lvl3/expand_str/expand_str.ref "" >> test_output.txt
./rendus/lvl3/expand_str/expand_str.out "quelle est la difference entre un bebe mort et un sandwich au poulet          ? " >> user_output.txt
./rendus/lvl3/expand_str/expand_str.ref "quelle est la difference entre un bebe mort et un sandwich au poulet          ? " >> test_output.txt
./rendus/lvl3/expand_str/expand_str.out "..." >> user_output.txt
./rendus/lvl3/expand_str/expand_str.ref "..." >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl3/expand_str.trace.txt
rm -f *output.txt
rm -f test.sh
