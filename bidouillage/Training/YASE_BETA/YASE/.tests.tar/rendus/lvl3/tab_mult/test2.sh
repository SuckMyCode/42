./rendus/lvl3/tab_mult/tab_mult.out > user_output.txt
./rendus/lvl3/tab_mult/tab_mult.ref > test_output.txt
./rendus/lvl3/tab_mult/tab_mult.out 1 >> user_output.txt
./rendus/lvl3/tab_mult/tab_mult.ref 1 >> test_output.txt
./rendus/lvl3/tab_mult/tab_mult.out 5 >> user_output.txt
./rendus/lvl3/tab_mult/tab_mult.ref 5 >> test_output.txt
./rendus/lvl3/tab_mult/tab_mult.out 9 >> user_output.txt
./rendus/lvl3/tab_mult/tab_mult.ref 9 >> test_output.txt
./rendus/lvl3/tab_mult/tab_mult.out 27 >> user_output.txt
./rendus/lvl3/tab_mult/tab_mult.ref 27 >> test_output.txt
./rendus/lvl3/tab_mult/tab_mult.out 144 >> user_output.txt
./rendus/lvl3/tab_mult/tab_mult.ref 144 >> test_output.txt
./rendus/lvl3/tab_mult/tab_mult.out 645769 >> user_output.txt
./rendus/lvl3/tab_mult/tab_mult.ref 645769 >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl3/tab_mult.trace.txt
rm -f *output.txt
rm -f test.sh
