./rendus/lvl3/print_hex/print_hex.out > user_output.txt
./rendus/lvl3/print_hex/print_hex.ref > test_output.txt
./rendus/lvl3/print_hex/print_hex.out "10" >> user_output.txt
./rendus/lvl3/print_hex/print_hex.ref "10" >> test_output.txt
./rendus/lvl3/print_hex/print_hex.out "4554587" >> user_output.txt
./rendus/lvl3/print_hex/print_hex.ref "4554587" >> test_output.txt
./rendus/lvl3/print_hex/print_hex.out "150444444" >> user_output.txt
./rendus/lvl3/print_hex/print_hex.ref "150444444" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl3/print_hex.trace.txt
rm -f *output.txt
rm -f test.sh
