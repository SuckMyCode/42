./rendus/lvl3/add_prime_sum/add_prime_sum.out > user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref > test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "17" "23" "42" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "17" "23" "42" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "-334" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "-334" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "-493" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "-493" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "676" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "676" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "319" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "319" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "350" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "350" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "660" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "660" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "265" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "265" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "641" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "641" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "657" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "657" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "671" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "671" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "1463" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "1463" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "1937" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "1937" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "1733" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "1733" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "1767" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "1767" >> test_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.out "1580" >> user_output.txt
./rendus/lvl3/add_prime_sum/add_prime_sum.ref "1580" >> test_output.txt


diff -U 3 user_output.txt test_output.txt > ./traces/lvl3/add_prime_sum.trace.txt
rm -f *output.txt
rm -f test.sh
