./rendus/lvl3/hidenp/hidenp.out > user_output.txt
./rendus/lvl3/hidenp/hidenp.ref > test_output.txt
./rendus/lvl3/hidenp/hidenp.out "abc" "a" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "abc" "a" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "" "abc" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "" "abc" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "abc" "" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "abc" "" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "abc" "abc" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "abc" "abc" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "abc" "adbc" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "abc" "adbc" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "abc" "adcb" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "abc" "adcb" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "abc" "adcbjgieuwhc" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "abc" "adcbjgieuwhc" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "abc" "adbcd" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "abc" "adbcd" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "abc" "abababababababab" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "abc" "abababababababab" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "zzzzzz" "z" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "zzzzzz" "z" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "zzzzzz" "zzzz" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "zzzzzz" "zzzz" >> test_output.txt
./rendus/lvl3/hidenp/hidenp.out "zzzzzz" "azzzzzzzzzzzzz" >> user_output.txt
./rendus/lvl3/hidenp/hidenp.ref "zzzzzz" "azzzzzzzzzzzzz" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl3/hidenp.trace.txt
rm -f *output.txt
rm -f test.sh
