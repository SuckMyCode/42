./rendus/lvl3/ft_swap/ft_swap.out > user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref > test_output.txt
./rendus/lvl3/ft_swap/ft_swap.out "-870974327" "-1917842433" >> user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref "-870974327" "-1917842433" >> test_output.txt
./rendus/lvl3/ft_swap/ft_swap.out "-795470802" "985690211" >> user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref "-795470802" "985690211" >> test_output.txt
./rendus/lvl3/ft_swap/ft_swap.out "973746209" "56849029" >> user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref "973746209" "56849029" >> test_output.txt
./rendus/lvl3/ft_swap/ft_swap.out "-491171638" "-1267621020" >> user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref "-491171638" "-1267621020" >> test_output.txt
./rendus/lvl3/ft_swap/ft_swap.out "-1763456208" "2135634121" >> user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref "-1763456208" "2135634121" >> test_output.txt
./rendus/lvl3/ft_swap/ft_swap.out "1182780310" "-921219670" >> user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref "1182780310" "-921219670" >> test_output.txt
./rendus/lvl3/ft_swap/ft_swap.out "-851861446" "-978395249" >> user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref "-851861446" "-978395249" >> test_output.txt
./rendus/lvl3/ft_swap/ft_swap.out "1452510974" "250333047" >> user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref "1452510974" "250333047" >> test_output.txt
./rendus/lvl3/ft_swap/ft_swap.out "-1956091649" "-126083344" >> user_output.txt
./rendus/lvl3/ft_swap/ft_swap.ref "-1956091649" "-126083344" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl3/ft_swap.trace.txt
rm -f *output.txt
rm -f test.sh
