./rendus/lvl3/str_capitalizer/str_capitalizer.out > user_output.txt
./rendus/lvl3/str_capitalizer/str_capitalizer.ref > test_output.txt
./rendus/lvl3/str_capitalizer/str_capitalizer.out "17" "23" "42" >> user_output.txt
./rendus/lvl3/str_capitalizer/str_capitalizer.ref "17" "23" "42" >> test_output.txt
./rendus/lvl3/str_capitalizer/str_capitalizer.out "4Hn82arQVcsA6Ke" >> user_output.txt
./rendus/lvl3/str_capitalizer/str_capitalizer.ref "4Hn82arQVcsA6Ke" >> test_output.txt
./rendus/lvl3/str_capitalizer/str_capitalizer.out "AuHa" >> user_output.txt
./rendus/lvl3/str_capitalizer/str_capitalizer.ref "AuHa" >> test_output.txt
./rendus/lvl3/str_capitalizer/str_capitalizer.out "PdVmwT" >> user_output.txt
./rendus/lvl3/str_capitalizer/str_capitalizer.ref "8shKMYf2H90EOVpGt" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl3/str_capitalizer.trace.txt
rm -f *output.txt
rm -f test.sh
