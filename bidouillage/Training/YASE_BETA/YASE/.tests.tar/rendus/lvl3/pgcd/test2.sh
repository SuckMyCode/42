./rendus/lvl3/pgcd/pgcd.out > user_output.txt
./rendus/lvl3/pgcd/pgcd.ref > test_output.txt
./rendus/lvl3/pgcd/pgcd.out "920556" "1980488" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "920556" "1980488" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "110360" "116932" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "110360" "116932" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "9001392" "2568344" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "9001392" "2568344" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "4696941" "4664522" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "4696941" "4664522" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "2184164" "5139728" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "2184164" "5139728" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "168857" "103974" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "168857" "103974" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "1741531" "451333" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "1741531" "451333" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "1803684" "3539916" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "1803684" "3539916" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "6459449" "608205" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "6459449" "608205" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "10166382" "148932" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "10166382" "148932" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "13522854" "8166288" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "13522854" "8166288" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "15" "18" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "15" "18" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "1" "17" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "1" "17" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "17" "33" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "17" "33" >> test_output.txt
./rendus/lvl3/pgcd/pgcd.out "42" "4324232" >> user_output.txt
./rendus/lvl3/pgcd/pgcd.ref "42" "4324232" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl3/pgcd.trace.txt
rm -f *output.txt
rm -f test.sh
