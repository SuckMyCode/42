./rendus/lvl0/ft_countdown/ft_countdown.out > user_output.txt | cat -e
./rendus/lvl0/ft_countdown/ft_countdown.ref > test_output.txt | cat -e

diff -U 3 user_output.txt test_output.txt > ./traces/lvl0/ft_countdown.trace.txt
rm -f *output.txt
rm -f test2.sh
