./rendus/lvl0/aff_first_param/aff_first_param.out > user_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.ref > test_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.out "1PkcVbamt3xSKTRdX" >> user_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.ref "1PkcVbamt3xSKTRdX" >> test_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.out "fKYUM" >> user_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.ref "fKYUM" >> test_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.out "SzON o4sL 8 NIM3jGYJE Dx5V8 LCIX6siZNaF5 UyZpJtogA otC36pl82 Y4fh HxGWb MW2 zv1eaDWQpOk jGQ olEAGeJgTZ" >> user_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.ref "SzON o4sL 8 NIM3jGYJE Dx5V8 LCIX6siZNaF5 UyZpJtogA otC36pl82 Y4fh HxGWb MW2 zv1eaDWQpOk jGQ olEAGeJgTZ" >> test_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.out "mkhMP TBatv7 2CQk934E NF tF2lzW nrCuDb9QRw7 IzXgY" >> user_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.ref "mkhMP TBatv7 2CQk934E NF tF2lzW nrCuDb9QRw7 IzXgY" >> test_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.out "wgVc0q" "u9eNLoC" "R4Cm0X7dpSGL" "f5O7myTZ" "p4Ehqio" "5PRqlTVHBhsD" "5mnyr1vlNca" >> user_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.ref "wgVc0q" "u9eNLoC" "R4Cm0X7dpSGL" "f5O7myTZ" "p4Ehqio" "5PRqlTVHBhsD" "5mnyr1vlNca" >> test_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.out "jPH" "aLyV" "P" "PwLzp" "0u6VKxy2cnm7" "l1tBhFXG" "9yk7oA1C" "ay" "P5v2VLt6In" "mv1WftdNxa" "BAp" >> user_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.ref "jPH" "aLyV" "P" "PwLzp" "0u6VKxy2cnm7" "l1tBhFXG" "9yk7oA1C" "ay" "P5v2VLt6In" "mv1WftdNxa" "BAp" >> test_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.out "Jre LJPzMKG X6tcoU3CLWw" "zm W80fK1OLst9 09mKZtPhBXvf ZtJgEBWYrH" "Qq 2ixkWzGQYI 6UXT2gq" "1Yhv vJ3iyMSaI Ei 1YGjxuygdm" "HeyWbL G4JV0TfXecq" "OjmpMFoR" "KQGq53 gMk" "A3LkhFfulze XW8Uolk lPj KPUfysO" "odKf gQui1DM" "TbXxnULCj4Ru e 9M46 IVFPUaEL" "otcs S1r" "LTJQoa7rfN9V H9r" "LNMbEq" >> user_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.ref "Jre LJPzMKG X6tcoU3CLWw" "zm W80fK1OLst9 09mKZtPhBXvf ZtJgEBWYrH" "Qq 2ixkWzGQYI 6UXT2gq" "1Yhv vJ3iyMSaI Ei 1YGjxuygdm" "HeyWbL G4JV0TfXecq" "OjmpMFoR" "KQGq53 gMk" "A3LkhFfulze XW8Uolk lPj KPUfysO" "odKf gQui1DM" "TbXxnULCj4Ru e 9M46 IVFPUaEL" "otcs S1r" "LTJQoa7rfN9V H9r" "LNMbEq" >> test_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.out "pMsyerPOIf OxJH39p yeLhOUM" "fC 8adygeVNH 6f2LD5Q" "YSvoApkCg8Ul" "9gmGC ugWt" "Ww 3WN8dQpRyG g JsavUf" "GcOxey" "jBTpdI mJCQYgIn7NG soiCPN6HvSwg Iho" "E2n9 YtSJ7gByFq oRE9m7O MmHht" "MN" "RHaskm56jK zlshO YE" >> user_output.txt | cat -e
./rendus/lvl0/aff_first_param/aff_first_param.ref "pMsyerPOIf OxJH39p yeLhOUM" "fC 8adygeVNH 6f2LD5Q" "YSvoApkCg8Ul" "9gmGC ugWt" "Ww 3WN8dQpRyG g JsavUf" "GcOxey" "jBTpdI mJCQYgIn7NG soiCPN6HvSwg Iho" "E2n9 YtSJ7gByFq oRE9m7O MmHht" "MN" "RHaskm56jK zlshO YE" >> test_output.txt | cat -e

diff -U 3 user_output.txt test_output.txt > ./traces/lvl0/aff_first_param.trace.txt
rm -f *output.txt
rm -f test.sh
