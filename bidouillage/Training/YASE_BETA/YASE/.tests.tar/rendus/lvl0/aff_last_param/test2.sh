./rendus/lvl0/aff_last_param/aff_last_param.out > user_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.ref > test_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.out "C4vDTLZFU7Nmy" >> user_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.ref "C4vDTLZFU7Nmy" >> test_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.out "RHwmvZij82lzLKU4" >> user_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.ref "RHwmvZij82lzLKU4" >> test_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.out "5IJMbcqtoSZV HOtcFufSy nOri J8M4xGFRyUo3" >> user_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.ref "5IJMbcqtoSZV HOtcFufSy nOri J8M4xGFRyUo3" >> test_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.out "VWyPgc3qBUG UwRaPiM2N YhmOzHn1A5 JAmaY qPX5An caIqGCKj fCbI3cFQMtul XK8fT l Rm60ryHsv9 dAxmk GnCYSJ0 rbtKMCZ" >> user_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.ref "VWyPgc3qBUG UwRaPiM2N YhmOzHn1A5 JAmaY qPX5An caIqGCKj fCbI3cFQMtul XK8fT l Rm60ryHsv9 dAxmk GnCYSJ0 rbtKMCZ" >> test_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.out "oq5THDCkMu" "2KHL7IUO" "XSxzHGao82W" "uXavVKcJ" >> user_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.ref "oq5THDCkMu" "2KHL7IUO" "XSxzHGao82W" "uXavVKcJ" >> test_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.out "RhGoNM0B5Uy" "L" "0XZ3z" "ZaBr10so3e" "5PUAK7VypHu" "U7" "57lc2wFj" "Hk03Zotl" "jdy6wagkTq" "GUg7YhTn4zeV" "Grdyba" >> user_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.ref "RhGoNM0B5Uy" "L" "0XZ3z" "ZaBr10so3e" "5PUAK7VypHu" "U7" "57lc2wFj" "Hk03Zotl" "jdy6wagkTq" "GUg7YhTn4zeV" "Grdyba" >> test_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.out "OLZhV8qPN" "CGe5no ct6lZ5FN" "86Ha0Agp ep 5A DYy1gaQTB3" "a O6qIGjDLox" "ezaHcD4J1XQf Dp7z8FegG qNuVORy9pGk X6JaoL" "lrg RyfhQ1 ob9fsON2gn7c T" "ljc7sqI jyH CkRcT7XEF" "uLMI1 BOCWR JyoHDq" "A9T k95eSy4UrfL o" "PvF" "vNxADtis9R" >> user_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.ref "OLZhV8qPN" "CGe5no ct6lZ5FN" "86Ha0Agp ep 5A DYy1gaQTB3" "a O6qIGjDLox" "ezaHcD4J1XQf Dp7z8FegG qNuVORy9pGk X6JaoL" "lrg RyfhQ1 ob9fsON2gn7c T" "ljc7sqI jyH CkRcT7XEF" "uLMI1 BOCWR JyoHDq" "A9T k95eSy4UrfL o" "PvF" "vNxADtis9R" >> test_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.out "sv lxCIOejUFR vPkCt" "aOGiD3sL" "TdN 7dCbMmnG" "HJXFQSg 1kCW7zbFZ 0ifbWFuB X" "RBoEP680HCau CUvsB5m VsvGnLx NYBzv9MZpgKL" "2Iw39Nn EAmq3R6pFga2" "89EYQtsUxvN1 CeU1XgwF 1g 2" "NBMCj CqgvzmutNj" "He" "IN" "TwnRmydq7D" "VXlNq7K8ecxo xh2IXuVf" "W s" "SyRzf UTIhR0xoVQ" >> user_output.txt | cat -e
./rendus/lvl0/aff_last_param/aff_last_param.ref "sv lxCIOejUFR vPkCt" "aOGiD3sL" "TdN 7dCbMmnG" "HJXFQSg 1kCW7zbFZ 0ifbWFuB X" "RBoEP680HCau CUvsB5m VsvGnLx NYBzv9MZpgKL" "2Iw39Nn EAmq3R6pFga2" "89EYQtsUxvN1 CeU1XgwF 1g 2" "NBMCj CqgvzmutNj" "He" "IN" "TwnRmydq7D" "VXlNq7K8ecxo xh2IXuVf" "W s" "SyRzf UTIhR0xoVQ" >> test_output.txt | cat -e

diff -U 3 user_output.txt test_output.txt > ./traces/lvl0/aff_last_param.trace.txt
rm -f *output.txt
rm -f test.sh
