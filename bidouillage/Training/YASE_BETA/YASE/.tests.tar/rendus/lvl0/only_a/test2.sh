./rendus/lvl0/only_a/only_a.out > user_output.txt
./rendus/lvl0/only_a/only_a.ref > test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl0/only_a.trace.txt
rm -f *output.txt
rm -f test.sh
