./rendus/lvl0/only_z/only_z.out > user_output.txt
./rendus/lvl0/only_z/only_z.ref > test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl0/only_z.trace.txt
rm -f *output.txt
rm -f test.sh
