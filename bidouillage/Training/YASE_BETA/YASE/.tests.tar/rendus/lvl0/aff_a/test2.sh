./rendus/lvl0/aff_a/aff_a.out > user_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.ref > test_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.out "17" "23" "42" >> user_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.ref "17" "23" "42" >> test_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.out "4Hn82arQVcsA6Ke" >> user_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.ref "4Hn82arQVcsA6Ke" >> test_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.out "AuHa" >> user_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.ref "AuHa" >> test_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.out "PdVmwT" >> user_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.ref "PdVmwT" >> test_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.out "8shKMYf2H90EOVpGt" >> user_output.txt | cat -e
./rendus/lvl0/aff_a/aff_a.ref "8shKMYf2H90EOVpGt" >> test_output.txt | cat -e

diff -U 3 user_output.txt test_output.txt > ./traces/lvl0/aff_a.trace.txt
rm -f *output.txt
rm -f test.sh
