./rendus/lvl0/ft_print_numbers/ft_print_numbers.out > user_output.txt | cat -e
./rendus/lvl0/ft_print_numbers/ft_print_numbers.ref > test_output.txt | cat -e
./rendus/lvl0/ft_print_numbers/ft_print_numbers.out "17" "23" "42" >> user_output.txt | cat -e
./rendus/lvl0/ft_print_numbers/ft_print_numbers.ref "17" "23" "42" >> test_output.txt | cat -e
./rendus/lvl0/ft_print_numbers/ft_print_numbers.out "4Hn82arQVcsA6Ke" >> user_output.txt | cat -e
./rendus/lvl0/ft_print_numbers/ft_print_numbers.ref "4Hn82arQVcsA6Ke" >> test_output.txt | cat -e
./rendus/lvl0/ft_print_numbers/ft_print_numbers.out "AuHa" >> user_output.txt | cat -e
./rendus/lvl0/ft_print_numbers/ft_print_numbers.ref "AuHa" >> test_output.txt | cat -e
./rendus/lvl0/ft_print_numbers/ft_print_numbers.out "PdVmwT" >> user_output.txt | cat -e
./rendus/lvl0/ft_print_numbers/ft_print_numbers.ref "8shKMYf2H90EOVpGt" >> test_output.txt | cat -e

diff -U 3 user_output.txt test_output.txt > ./traces/lvl0/ft_print_numbers.trace.txt
rm -f *output.txt
rm -f test.sh
