./rendus/lvl1/ft_putstr/ft_putstr.out > user_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.ref > test_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.out "pCYLoDQIBjGnri1" >> user_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.ref "pCYLoDQIBjGnri1" >> test_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.out "HtzkQUmagj" >> user_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.ref "HtzkQUmagj" >> test_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.out "TIzKGCqHnJPYOZg79" >> user_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.ref "TIzKGCqHnJPYOZg79" >> test_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.out "vd9 QuIE B78 2S4PJFOELtWw 03Id6KvM2wg" >> user_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.ref "vd9 QuIE B78 2S4PJFOELtWw 03Id6KvM2wg" >> test_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.out "2v9RwCKZWkETfsy A1VWPj fnpZu5j8Brcs 2XdoEZe0LgDJHvRP iUVJwsdmPnBODk2Yx d04OWeu53tLsMDHNa yeax kAKgt5RNLsM9v zfxmgbW1 fzmtWL71 ZAefwMJ I2NCpHLaJUQsDmz emZ0 ojDMO uQqlhTNC 0FhC2zuvfHNR dXBLkTzEJhUc" >> user_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.ref "2v9RwCKZWkETfsy A1VWPj fnpZu5j8Brcs 2XdoEZe0LgDJHvRP iUVJwsdmPnBODk2Yx d04OWeu53tLsMDHNa yeax kAKgt5RNLsM9v zfxmgbW1 fzmtWL71 ZAefwMJ I2NCpHLaJUQsDmz emZ0 ojDMO uQqlhTNC 0FhC2zuvfHNR dXBLkTzEJhUc" >> test_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.out "1SZ6MYOk9 cSgiFG2a TXr WH8JxKFtqRXID XHTx os1KiRQTzrDOWdy k6Tyov CYqcu7xKdMr2 T1Jw pzs2xY0 sTVw LmX YPzlv DkjQmb ehmjAHDPS AmuS0zpfcMx IBwKOcAV GPO02nHg" >> user_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.ref "1SZ6MYOk9 cSgiFG2a TXr WH8JxKFtqRXID XHTx os1KiRQTzrDOWdy k6Tyov CYqcu7xKdMr2 T1Jw pzs2xY0 sTVw LmX YPzlv DkjQmb ehmjAHDPS AmuS0zpfcMx IBwKOcAV GPO02nHg" >> test_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.out "My6geZ nGK9Qji3mHd rG79V4EK3gNT q6PIXAi85HSGr4l sPjZ2xdJpYW tRIlTdV5CakHUoxge MsCH6Va4Joi9lEtRx" >> user_output.txt
./rendus/lvl1/ft_putstr/ft_putstr.ref "My6geZ nGK9Qji3mHd rG79V4EK3gNT q6PIXAi85HSGr4l sPjZ2xdJpYW tRIlTdV5CakHUoxge MsCH6Va4Joi9lEtRx" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl1/ft_putstr.trace.txt
rm -f *output.txt
rm -f test.sh
