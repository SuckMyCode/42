./rendus/lvl1/rev_print/rev_print.out > user_output.txt
./rendus/lvl1/rev_print/rev_print.ref > test_output.txt
./rendus/lvl1/rev_print/rev_print.out "vBx7Y6Hj3" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "vBx7Y6Hj3" >> test_output.txt
./rendus/lvl1/rev_print/rev_print.out "H4X" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "H4X" >> test_output.txt
./rendus/lvl1/rev_print/rev_print.out "IhBN7xoEHrXzmuA" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "IhBN7xoEHrXzmuA" >> test_output.txt
./rendus/lvl1/rev_print/rev_print.out "Cag4Nfo8 8qoIumvhH IYMQO7igB KtZnsw2UB0X6SuTY" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "Cag4Nfo8 8qoIumvhH IYMQO7igB KtZnsw2UB0X6SuTY" >> test_output.txt
./rendus/lvl1/rev_print/rev_print.out "5CbjRxUDJ2d0krLey dZcLGKhEr7o m9gykNlah HARDVi SxNPtY0LmWIr EI1WTlta 0Ruoqte1T 9AgZlY6 6zjBhHgwkcu mJBEVp" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "5CbjRxUDJ2d0krLey dZcLGKhEr7o m9gykNlah HARDVi SxNPtY0LmWIr EI1WTlta 0Ruoqte1T 9AgZlY6 6zjBhHgwkcu mJBEVp" >> test_output.txt
./rendus/lvl1/rev_print/rev_print.out "z8fWqd SXy GTa TDHl0mC5nNe GVEO AGXTB5K27VMdi1a 7kcho8uOYVtCb uWMfBpgUVCEv2Am8 6AEqwYavu3LZSh FQlpU XKpJL8uO R1FpHEhYVn2S6zrq7 5zmH w4pqNAsMU0ISx wXmCF fvP" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "z8fWqd SXy GTa TDHl0mC5nNe GVEO AGXTB5K27VMdi1a 7kcho8uOYVtCb uWMfBpgUVCEv2Am8 6AEqwYavu3LZSh FQlpU XKpJL8uO R1FpHEhYVn2S6zrq7 5zmH w4pqNAsMU0ISx wXmCF fvP" >> test_output.txt
./rendus/lvl1/rev_print/rev_print.out "qKY" "jRx5YdboVsLv" "VIu1KkSi3lO" "SCleP9cTiRa" "nmX5FCT" "koLlh9TtMbcQ6" "nVx9z51ALbG4FoY" "5ndkFAZ" "nGiPh" "u1dvbckQXE0q" "pfzlxyjva" "bWNaegAG28zxYq5rO" "aNhcxkYrRplUwC" "O5RTMfG4xuy9JA" "MCEjmnNWAB8" "pA72S" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "qKY" "jRx5YdboVsLv" "VIu1KkSi3lO" "SCleP9cTiRa" "nmX5FCT" "koLlh9TtMbcQ6" "nVx9z51ALbG4FoY" "5ndkFAZ" "nGiPh" "u1dvbckQXE0q" "pfzlxyjva" "bWNaegAG28zxYq5rO" "aNhcxkYrRplUwC" "O5RTMfG4xuy9JA" "MCEjmnNWAB8" "pA72S" >> test_output.txt
./rendus/lvl1/rev_print/rev_print.out "dJRrgYukx8NAOaT" "OlMF" "yZXfza2xAsDTh" "FL1BcE" "3FMjGms" "wzFB" "Aa6N" "qc87" "0OVFzjKZd" "HXCNjSMURn5yf" "YcrOLtgmGd" "QR9yVZ" "pNU" "2EfshTmytJX4RM" "zOQJwpTVh2" "DKC1iohtvsg5JuL" "idE3DI07" "t1qY7P2T" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "dJRrgYukx8NAOaT" "OlMF" "yZXfza2xAsDTh" "FL1BcE" "3FMjGms" "wzFB" "Aa6N" "qc87" "0OVFzjKZd" "HXCNjSMURn5yf" "YcrOLtgmGd" "QR9yVZ" "pNU" "2EfshTmytJX4RM" "zOQJwpTVh2" "DKC1iohtvsg5JuL" "idE3DI07" "t1qY7P2T" >> test_output.txt
./rendus/lvl1/rev_print/rev_print.out "UcTMpyADfON qQapH IA8hnwKi INFPfT5uyslz O1ElIcjR3yU BnXmY9 B71biHNeJFWc" "uFQDq6 Qzyd OXSEb9 Ayx 60icGImSX QUNC4YSPOl7 eNc2gMt6Asr1B PCh6wZ x7NtFwuQ beKImSQ5kx8y NBKh anFgQ8LU9NAVvCbt 3P0JlZp5 T4QVx2" "N0WAfO9rSsBe Akea jt9ZUa j8sbMVf6CDiY blDzj8ycC 06rL3P PW9FGp 9lh5DkfuyQ r4sudlMzb6L wK7JRq6FVxLohD4I vLTQKsnp C2teUXVD9EIs jY9Gu Upcm8lYFPyu4zHfnE a2GDn8iN1V b3582CW G2VJjI" "JHg Vp25LszeHWc 0AyG7Y1wPCDkb eu0kGSQ9v81I tyo7CXD93dzrxpLjF LyW0aAZ" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "UcTMpyADfON qQapH IA8hnwKi INFPfT5uyslz O1ElIcjR3yU BnXmY9 B71biHNeJFWc" "uFQDq6 Qzyd OXSEb9 Ayx 60icGImSX QUNC4YSPOl7 eNc2gMt6Asr1B PCh6wZ x7NtFwuQ beKImSQ5kx8y NBKh anFgQ8LU9NAVvCbt 3P0JlZp5 T4QVx2" "N0WAfO9rSsBe Akea jt9ZUa j8sbMVf6CDiY blDzj8ycC 06rL3P PW9FGp 9lh5DkfuyQ r4sudlMzb6L wK7JRq6FVxLohD4I vLTQKsnp C2teUXVD9EIs jY9Gu Upcm8lYFPyu4zHfnE a2GDn8iN1V b3582CW G2VJjI" "JHg Vp25LszeHWc 0AyG7Y1wPCDkb eu0kGSQ9v81I tyo7CXD93dzrxpLjF LyW0aAZ" >> test_output.txt
./rendus/lvl1/rev_print/rev_print.out "EZWAYw OaSQzK1yw2 VpDNmPfFZSbsBiah Xk8g BpNL 5vjtNl8ry69haopwb 9acpr PcZLmK OAF8rmK5wZzY2 Rj1fWI7JqDPxO JvdO6FH 6oiYn84uJmD1pTQhB" "VjWDEwt vclbtSu3qLA8ePTE HLeNg8uhSW kB1zHsJ2OFevfhA 18YLwyAexj smNdHl1gVGBz WqKrh1bOR X0yJ4dVq8L PUY7x9V" >> user_output.txt
./rendus/lvl1/rev_print/rev_print.ref "EZWAYw OaSQzK1yw2 VpDNmPfFZSbsBiah Xk8g BpNL 5vjtNl8ry69haopwb 9acpr PcZLmK OAF8rmK5wZzY2 Rj1fWI7JqDPxO JvdO6FH 6oiYn84uJmD1pTQhB" "VjWDEwt vclbtSu3qLA8ePTE HLeNg8uhSW kB1zHsJ2OFevfhA 18YLwyAexj smNdHl1gVGBz WqKrh1bOR X0yJ4dVq8L PUY7x9V" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > traces/lvl1/rev_print.trace.txt
rm -f *output.txt
rm -f test.sh
