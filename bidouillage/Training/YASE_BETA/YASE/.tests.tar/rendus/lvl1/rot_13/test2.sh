./rendus/lvl1/rot_13/rot_13.out > user_output.txt
./rendus/lvl1/rot_13/rot_13.ref > test_output.txt
./rendus/lvl1/rot_13/rot_13.out "QCjAu" >> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "QCjAu" >> test_output.txt
./rendus/lvl1/rot_13/rot_13.out "5KDa08uFkERLlzZr" >> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "5KDa08uFkERLlzZr" >> test_output.txt
./rendus/lvl1/rot_13/rot_13.out "FWLP5ilzQ2Tok" >> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "FWLP5ilzQ2Tok" >> test_output.txt
./rendus/lvl1/rot_13/rot_13.out "GqMzdlnm PgtXwA XMk4VoCw3H jSxoCkMErcGuZ5mY1 9WIy8G" >> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "GqMzdlnm PgtXwA XMk4VoCw3H jSxoCkMErcGuZ5mY1 9WIy8G" >> test_output.txt
./rendus/lvl1/rot_13/rot_13.out "bNesBf35J9Zvi 7Ic40ODQ AWHO7baej JGbu" >> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "bNesBf35J9Zvi 7Ic40ODQ AWHO7baej JGbu" >> test_output.txt
./rendus/lvl1/rot_13/rot_13.out "xBlKFm3b1MJE6rtG TtXCZ VehOotmPRru xQJ 6A1bmv yx2aDwLNq r3a0sUDLgR71AT edplE 3onWskfgNFrGt9 SnYKf4vwWBzlDL WFSca02H u3MgpdtIwWXyr 6YhpJrcFIn" >> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "xBlKFm3b1MJE6rtG TtXCZ VehOotmPRru xQJ 6A1bmv yx2aDwLNq r3a0sUDLgR71AT edplE 3onWskfgNFrGt9 SnYKf4vwWBzlDL WFSca02H u3MgpdtIwWXyr 6YhpJrcFIn" >> test_output.txt
./rendus/lvl1/rot_13/rot_13.out "RQgzFjcvMKBW3dnID" "Xop6KZ1w304YRG" "4TxKE6caAwb" "aec" "oTYG1yrxwec" "P7MR3db9L" "RQzqiuUtO5vrfy8C" "TMa1Cx8" "Cpi" "kTrJ" "7aj"
>> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "RQgzFjcvMKBW3dnID" "Xop6KZ1w304YRG" "4TxKE6caAwb" "aec" "oTYG1yrxwec" "P7MR3db9L" "RQzqiuUtO5vrfy8C" "TMa1Cx8" "Cpi" "kTrJ" "7aj"
>> test_output.txt
./rendus/lvl1/rot_13/rot_13.out "b73" "MNpFrX7Za2gbow" "Swj" "TrsDCGFY0NxKdvp5j" "eSW5MyGkRm2" "IE6p1gWe" "o0O6UA" "6EHeZ0t5" >> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "b73" "MNpFrX7Za2gbow" "Swj" "TrsDCGFY0NxKdvp5j" "eSW5MyGkRm2" "IE6p1gWe" "o0O6UA" "6EHeZ0t5" >> test_output.txt
./rendus/lvl1/rot_13/rot_13.out "B4cC6rhI1sfwyoi0 mloH6haOCAxUjEVN mESZKjGYRdFrB0g rs27 daLmrVnRvUQ FTldjMZfxoBW8Qb Lzsfg AJFo4CTkXrPac62 GXVltamAU1Efs5o PJ5clBIfsHW z8amWV epjNJ QBu4s5Xk6an 0BJE pX4hi UP5cKzMAEf fVAzvHbWL1S SfPs3QqO" "i5v tNgsSx1oOpDKGAY ao4r 4vF2EgiT6 ImSR O7Ai9Qqbs sPlQaVLEc0ZR 25EvCi nNavbseXDVxZk9Rp4 aMp5JQLzPWZA76I03 jh6nUG1E g9o5dOyBwQPXvx tFiIg0EZdL7myv ePp3 hat" "Zg7TAYLb ZAOfXQqvR8Bnrui X165 kYZKiFOWHvhx Bm3T6LqNyI Ertp1D2wZdh7" "ULonmjEDMvaeYwfb gyJps QfzxImsvORuUc vgL IV5Kf8Wb9 t1K ce5XrO8 pm9fdsK N8eAWEFTjsnJY1qt zujIflCND7Lk Kk9wUYejSl 1qYon cnFBRI97 qmXEF rZW6xmFceyHziV5fj aymM2D NlZh2WE7JPoHjy0u lxCoEu" "cLO 4ltoBi2UrVyQ3 Xx3YTZJhzwU6 Y4f" "TAswnuDIU0vY47Z RLWY30aGiD47 p1cANx4YHT i60Nfx8w1MARrW chpD0CVF3 JRaOWnLbZeEf6 u4H61VwFcCvLSA3IZ E5RB I2OxeTglB mvY6N ygM9sXWVE3BbxZQ LlnXWG" >> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "B4cC6rhI1sfwyoi0 mloH6haOCAxUjEVN mESZKjGYRdFrB0g rs27 daLmrVnRvUQ FTldjMZfxoBW8Qb Lzsfg AJFo4CTkXrPac62 GXVltamAU1Efs5o PJ5clBIfsHW z8amWV epjNJ QBu4s5Xk6an 0BJE pX4hi UP5cKzMAEf fVAzvHbWL1S SfPs3QqO" "i5v tNgsSx1oOpDKGAY ao4r 4vF2EgiT6 ImSR O7Ai9Qqbs sPlQaVLEc0ZR 25EvCi nNavbseXDVxZk9Rp4 aMp5JQLzPWZA76I03 jh6nUG1E g9o5dOyBwQPXvx tFiIg0EZdL7myv ePp3 hat" "Zg7TAYLb ZAOfXQqvR8Bnrui X165 kYZKiFOWHvhx Bm3T6LqNyI Ertp1D2wZdh7" "ULonmjEDMvaeYwfb gyJps QfzxImsvORuUc vgL IV5Kf8Wb9 t1K ce5XrO8 pm9fdsK N8eAWEFTjsnJY1qt zujIflCND7Lk Kk9wUYejSl 1qYon cnFBRI97 qmXEF rZW6xmFceyHziV5fj aymM2D NlZh2WE7JPoHjy0u lxCoEu" "cLO 4ltoBi2UrVyQ3 Xx3YTZJhzwU6 Y4f" "TAswnuDIU0vY47Z RLWY30aGiD47 p1cANx4YHT i60Nfx8w1MARrW chpD0CVF3 JRaOWnLbZeEf6 u4H61VwFcCvLSA3IZ E5RB I2OxeTglB mvY6N ygM9sXWVE3BbxZQ LlnXWG" >> test_output.txt
./rendus/lvl1/rot_13/rot_13.out "jIMx XvCSqs zKHk15mQEI2y9eu Wi4Juldv3B7czP vEUalIk0emQJ WGsDiwSLtyhNPOB1 fEm qP7vmWnpE1Jj hmCM5Rsq2iX4Sj dCeEB9NGF3ObV57Y vU6R" "XJcxt8gBPeoAjCE2 BFL9uhqXVyzKNv Ngm9ryhX3uwA UMl9WN5dA pbri0A3QWs145h YjL" "KknvWdXY1hP k5HTtI Jr8aDvgHF7XIs fyd xjp7V04Mh8 9cA5FkKnB NUVBjvPkSK1H2yt HG9JENltRMP5pX NvGCIDmKjfYM iKsCpeA0aZyNBR52 kvaq mbEled lUt q0oaUeTGuDg42 AUO8kLQj" "wcsCe2j7RE geUtwJIsW wcLn2 YUW o3mBW8a26 72omtOnzfR YfIqxQ0B 7JZLqnWF8E JXHA0SjdolGh wyP7 IM8EUNHAdo6i3b AaudSZR0z o4qZJH0xLOFnRjf5b" "cQRg53B iSkRBAoU2g RkaCsu2y45xqp xlBWV2F4qJ sg6e1ButPfCmY3NXZ WOnM omNbtE Y2bSLuZsMB7F 0qLAxz5kiWGP DEbGnvKY lRN4KYf" >> user_output.txt
./rendus/lvl1/rot_13/rot_13.ref "jIMx XvCSqs zKHk15mQEI2y9eu Wi4Juldv3B7czP vEUalIk0emQJ WGsDiwSLtyhNPOB1 fEm qP7vmWnpE1Jj hmCM5Rsq2iX4Sj dCeEB9NGF3ObV57Y vU6R" "XJcxt8gBPeoAjCE2 BFL9uhqXVyzKNv Ngm9ryhX3uwA UMl9WN5dA pbri0A3QWs145h YjL" "KknvWdXY1hP k5HTtI Jr8aDvgHF7XIs fyd xjp7V04Mh8 9cA5FkKnB NUVBjvPkSK1H2yt HG9JENltRMP5pX NvGCIDmKjfYM iKsCpeA0aZyNBR52 kvaq mbEled lUt q0oaUeTGuDg42 AUO8kLQj" "wcsCe2j7RE geUtwJIsW wcLn2 YUW o3mBW8a26 72omtOnzfR YfIqxQ0B 7JZLqnWF8E JXHA0SjdolGh wyP7 IM8EUNHAdo6i3b AaudSZR0z o4qZJH0xLOFnRjf5b" "cQRg53B iSkRBAoU2g RkaCsu2y45xqp xlBWV2F4qJ sg6e1ButPfCmY3NXZ WOnM omNbtE Y2bSLuZsMB7F 0qLAxz5kiWGP DEbGnvKY lRN4KYf" >> test_output.txt
diff -U 3 user_output.txt test_output.txt > ./traces/lvl1/rot_13.trace.txt
rm -f *output.txt
rm -f test.sh
