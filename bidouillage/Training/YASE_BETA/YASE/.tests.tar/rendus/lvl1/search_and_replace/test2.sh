./rendus/lvl1/search_and_replace/search_and_replace.out > user_output.txt
./rendus/lvl1/search_and_replace/search_and_replace.ref > test_output.txt
./rendus/lvl1/search_and_replace/search_and_replace.out "L'amour, c'est comme la grippe, ca s'attrape dans la rue et ca se finit au lit." "m" "n" >> user_output.txt
./rendus/lvl1/search_and_replace/search_and_replace.ref "L'amour, c'est comme la grippe, ca s'attrape dans la rue et ca se finit au lit." "m" "n" >> test_output.txt
./rendus/lvl1/search_and_replace/search_and_replace.out "ceci est un test ou rien ne va changer" "w" "z" >> user_output.txt
./rendus/lvl1/search_and_replace/search_and_replace.ref "ceci est un test ou rien ne va changer" "w" "z" >> test_output.txt
./rendus/lvl1/search_and_replace/search_and_replace.out "voiCiI un Test POur les MajusculE hIhI" "I" "i" >> user_output.txt
./rendus/lvl1/search_and_replace/search_and_replace.ref "voiCiI un Test POur les MajusculE hIhI" "I" "i" >> test_output.txt
./rendus/lvl1/search_and_replace/search_and_replace.out "voiCiI un Test POur la longueurs des arg" "Ici" "i" >> user_output.txt
./rendus/lvl1/search_and_replace/search_and_replace.ref "voiCiI un Test POur la longueurs des arg" "Ici" "i" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl1/search_and_replace.trace.txt
rm -f *output.txt
rm -f test.sh
