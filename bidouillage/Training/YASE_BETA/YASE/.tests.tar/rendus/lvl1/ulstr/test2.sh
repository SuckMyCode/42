./rendus/lvl1/ulstr/ulstr.out > user_output.txt
./rendus/lvl1/ulstr/ulstr.ref > test_output.txt
./rendus/lvl1/ulstr/ulstr.out "L'eSPrit nE peUt plUs pRogResSer s'Il staGne et sI peRsIsTent VAnIte et auto-justification." >> user_output.txt
./rendus/lvl1/ulstr/ulstr.ref "L'eSPrit nE peUt plUs pRogResSer s'Il staGne et sI peRsIsTent VAnIte et auto-justification." >> test_output.txt
./rendus/lvl1/ulstr/ulstr.out "S'enTOuRer dE sECreT eSt uN sIGnE De mAnQuE De coNNaiSSanCe.  " >> user_output.txt
./rendus/lvl1/ulstr/ulstr.ref "S'enTOuRer dE sECreT eSt uN sIGnE De mAnQuE De coNNaiSSanCe.  " >> test_output.txt
./rendus/lvl1/ulstr/ulstr.out "3:21 Ba  tOut  moUn ki Ka di KE m'en Ka fe fot" >> user_output.txt
./rendus/lvl1/ulstr/ulstr.ref "3:21 Ba  tOut  moUn ki Ka di KE m'en Ka fe fot" >> test_output.txt
./rendus/lvl1/ulstr/ulstr.out "Pour l'Imperium de l'Humanite" >> user_output.txt
./rendus/lvl1/ulstr/ulstr.ref "Pour l'Imperium de l'Humanite" >> test_output.txt
./rendus/lvl1/ulstr/ulstr.out "..." >> user_output.txt
./rendus/lvl1/ulstr/ulstr.ref "..." >> test_output.txt
./rendus/lvl1/ulstr/ulstr.out "" >> user_output.txt
./rendus/lvl1/ulstr/ulstr.ref "" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl1/ulstr.trace.txt
rm -f *output.txt
rm -f test.sh
