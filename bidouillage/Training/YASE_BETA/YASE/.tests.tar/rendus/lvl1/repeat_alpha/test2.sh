./rendus/lvl1/repeat_alpha/repeat_alpha.out > user_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.ref > test_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.out lol mdr >> user_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.ref lol mdr >> test_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.out zaz >> user_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.ref zaz >> test_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.out "Alex." >> user_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.ref "Alex." >> test_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.out "abacadaba42" >> user_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.ref "abacadaba42" >> test_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.out "qperez il est pas chaud!tr0l0l0l" >> user_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.ref "qperez il est pas chaud!tr0l0l0l" >> test_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.out "j'aime bien les poney" >> user_output.txt
./rendus/lvl1/repeat_alpha/repeat_alpha.ref "j'aime bien les poney" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl1/repeat_alpha.trace.txt
rm -f *output.txt
rm -f test.sh
