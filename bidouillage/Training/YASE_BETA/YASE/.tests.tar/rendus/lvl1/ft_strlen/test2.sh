./rendus/lvl1/ft_strlen/ft_strlen.out > user_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.ref > test_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.out "" >> user_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.ref "" >> test_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.out "	" >> user_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.ref "	" >> test_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.out "1Qt2Ukx" >> user_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.ref "1Qt2Ukx" >> test_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.out "2s8U0h7BWKJINAk" >> user_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.ref "2s8U0h7BWKJINAk" >> test_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.out "6hEUK" >> user_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.ref "6hEUK" >> test_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.out "aMXNtFCWk Qczb2HN dqbIDkB79XlS2K 2QEmHh9sYtqJLb5ci W7YIoQkZsvD APzSOVDEiYg56ry MAeDCEl H30 21kwjTgsMvLK r6MgTI9ojD2xtlV SP42oGUWrKl1yeXf" >> user_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.ref "aMXNtFCWk Qczb2HN dqbIDkB79XlS2K 2QEmHh9sYtqJLb5ci W7YIoQkZsvD APzSOVDEiYg56ry MAeDCEl H30 21kwjTgsMvLK r6MgTI9ojD2xtlV SP42oGUWrKl1yeXf" >> test_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.out "JqbAwnB0Ku 0vTMgPrz W7KA pGJ3VYAOS4 SeDKM vz20MJ OG3cEMRKHtu6ACQS OCubdVSUNfxBM DujCHRcTJ5YM2F1" >> user_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.ref "JqbAwnB0Ku 0vTMgPrz W7KA pGJ3VYAOS4 SeDKM vz20MJ OG3cEMRKHtu6ACQS OCubdVSUNfxBM DujCHRcTJ5YM2F1" >> test_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.out "h7cPER2GKgeyAdH Dp9dsSgZATN4G0 TyIBRCDpJ HQncFjR3qC E54LxfvD7Qo hAYwkQIpm401RVE yrq" >> user_output.txt
./rendus/lvl1/ft_strlen/ft_strlen.ref "h7cPER2GKgeyAdH Dp9dsSgZATN4G0 TyIBRCDpJ HQncFjR3qC E54LxfvD7Qo hAYwkQIpm401RVE yrq" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl1/ft_strlen.trace.txt
rm -f *output.txt
rm -f test.sh
