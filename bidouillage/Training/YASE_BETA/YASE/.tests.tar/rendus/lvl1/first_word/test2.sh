./rendus/lvl1/first_word/first_word.out > user_output.txt
./rendus/lvl1/first_word/first_word.ref > test_output.txt
./rendus/lvl1/first_word/first_word.out "premier param" "deuxieme param" >> user_output.txt
./rendus/lvl1/first_word/first_word.ref "premier param" "deuxieme param" >> test_output.txt
./rendus/lvl1/first_word/first_word.out "rien ne sert de courir il faut partir a point" >> user_output.txt
./rendus/lvl1/first_word/first_word.ref "rien ne sert de courir il faut partir a point" >> test_output.txt
./rendus/lvl1/first_word/first_word.out "  et le trim, c'est pour les andouilles en ski  " >> user_output.txt
./rendus/lvl1/first_word/first_word.ref "  et le trim, c'est pour les andouilles en ski  " >> test_output.txt
./rendus/lvl1/first_word/first_word.out "..." >> user_output.txt
./rendus/lvl1/first_word/first_word.ref "..." >> test_output.txt
./rendus/lvl1/first_word/first_word.out "" >> user_output.txt
./rendus/lvl1/first_word/first_word.ref "" >> test_output.txt
./rendus/lvl1/first_word/first_word.out \" >> user_output.txt
./rendus/lvl1/first_word/first_word.ref \" >> test_output.txt

diff -U 3 user_output.txt test_output.txt > ./traces/lvl1/first_word.trace.txt
rm -f *output.txt
rm -f test.sh
