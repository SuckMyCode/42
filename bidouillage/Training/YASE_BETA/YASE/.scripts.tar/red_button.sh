rm -rf *
