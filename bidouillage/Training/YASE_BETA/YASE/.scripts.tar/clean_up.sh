rm -rf sujets/
rm -rf rendus/
rm -rf traces/lvl*/*.txt
rm -f grade_me.sh
rm -f red_button.sh
rm -f clean_up.sh
